<footer class="main-footer text-center">
    &copy; {{ date('Y') }}  
    <a href="https://totalofftec.com/" target="_blank" class="text-decoration-none">
        <strong>TOTALOFFTEC</strong>
    </a> 
    All rights reserved.
</footer>

